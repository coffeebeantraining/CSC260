﻿using System;
namespace SecondLowestCostPlan
{
    //String oemString = Enum.GetName(typeof(GroupTypes), GroupTypes.OEM);
    public enum MetalLevel
    {
        Silver,
        Gold,
        Bronze,
        Platinum,
        Catastrophic
    }
}

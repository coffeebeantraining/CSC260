﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SecondLowestCostPlan
{
    public class RateAreasImpl : RateAreas
    {
        public RateAreasImpl()
        {
        }

        public override IList ProcessCSV(string path)
        {
            var csvToList = File.ReadAllLines(path)
                .Skip(1)
                .Where(columns => columns.Length > 0)
                .Select(columns => columns.Split(','))
                .Select(columns => new RateAreasImpl()
                {
                    ZipCode = columns[0],
                    State = columns[1],
                    CountyCode = columns[2],
                    Name = columns[3],
                    RateArea = int.Parse(columns[4])
                }).Distinct()
                    .OrderBy(ord => ord.State)
                    .ThenBy(ord => ord.CountyCode)
                    .ThenBy(ord => ord.ZipCode)
                    .ThenBy(ord => ord.RateArea)
                    .ToList();

            return csvToList;
        }

        public override bool UpdateRateAreas()
        {
            bool refreshed = false;

            //set the location to the csv file and open it for reading
            using (FileStream fileStream = new FileStream(Config.HealthRatesInputFilePath, FileMode.Open, FileAccess.Read))
            {
                //read csv file
                using (StreamReader streamReader = new StreamReader(fileStream))
                {
                    //read the rate areas
                    string _rateAreas = streamReader.ReadToEnd().Trim();

                    //did the rate areas input file change from what is stored in cache?
                    if (String.Compare(_rateAreas, Config.RateAreasCompare, StringComparison.InvariantCultureIgnoreCase) != 0)
                    {
                        Config.RateAreasCompare = _rateAreas;
                        refreshed = true;
                    }

                }   //StreamReader

            }   //FileStream

            return refreshed;
        }


    }
}

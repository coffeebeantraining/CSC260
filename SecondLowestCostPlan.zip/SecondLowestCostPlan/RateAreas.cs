﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace SecondLowestCostPlan
{
    public abstract class RateAreas : IHealthPlans
    {

        private string _ZipCode;
        private string _CountyCode;
        private string _Name;

        public string ZipCode { get => _ZipCode; set => _ZipCode = value; }
        public string CountyCode { get => _CountyCode; set => _CountyCode = value; }
        public string Name { get => _Name; set => _Name = value; }

        public string State { get; set; }
        public int RateArea { get; set; }

        public virtual IList ProcessCSV(string path)
        {
            throw new NotImplementedException();
        }

        public virtual bool UpdateRateAreas()
        {
            throw new NotImplementedException();
        }
    }
}

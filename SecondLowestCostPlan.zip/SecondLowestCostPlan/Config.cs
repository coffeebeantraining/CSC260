﻿using System;
using System.IO;
using System.Threading;
using System.Web;
using System.Web.Hosting;
using System.Xml;

namespace SecondLowestCostPlan
{
    public static class Config
    {
        private static string _currentDirectory = Environment.CurrentDirectory.Substring(0, Environment.CurrentDirectory.LastIndexOf("\\bin\\", StringComparison.CurrentCulture));
        private static string _CONFIGPATH = string.Format("{0}/Config.xml", _currentDirectory);  //fixed this should not change.
        private static string _configPath = null;
        private static string _configCompare = null;        //in memory comparison to check if file contents change between reads.

        private static bool _shutdown;    //dynamic path that can be changed on the backend.
        public static bool Shutdown { get => _shutdown; set => _shutdown = value; }

        private static string _healthPlansInputFilePath;    //dynamic path that can be changed on the backend.

        public static string HealthPlansInputFilePath
        {
            get
            {
                return _healthPlansInputFilePath;
            }
        }

        private static string _rateAreasInputFilePath;

        public static string HealthRatesInputFilePath
        {
            get
            {
                return _rateAreasInputFilePath;
            }
        }

        private static string _slcpOutputFilePath;
        public static string SlcpOutputFilePath { get => _slcpOutputFilePath; set => _slcpOutputFilePath = value; }


        private static string _healthPlansCompare;

        public static string HealthPlansCompare { get => _healthPlansCompare; set => _healthPlansCompare = value; }

        public static string RateAreasCompare { get; set; }

        private static ManualResetEvent _primaryThreadStarted;
        private static ReaderWriterLock _mainWorkerLock = new ReaderWriterLock();
        private static ReaderWriterLock _settingsLock = new ReaderWriterLock();
        private static Thread _primaryThread;
        private static Thread _secondaryThread;

        static Config()
        {
            //create manual reset event
            _primaryThreadStarted = new ManualResetEvent(false);

            //spawn primary worker thread
            _primaryThread = new Thread(new ThreadStart(MainWorkerLoop));
            _primaryThread.Name = "Primary Worker Thread";
            _primaryThread.Start();

            //spawn secondary worker thread that monitors the primary thread
            _secondaryThread = new Thread(new ThreadStart(CheckPrimaryThreadAlive));
            _secondaryThread.Name = "Secondary Worker Thread";
            _secondaryThread.Start();
        }

        private static bool CreateMe()
        {
            while (_healthPlansInputFilePath == null && _rateAreasInputFilePath == null)
            {
                Thread.Sleep(TimeSpan.FromSeconds(1));
            }
            return (_healthPlansInputFilePath != null && _rateAreasInputFilePath != null);
        }


        public static bool CheckInstance()
        {
            return CreateMe();
        }

        //get application settings
        public static void GetApplicationSettings()
        {
            try
            {
                //acquire writer lock
                _settingsLock.AcquireWriterLock(1000);

                try
                {
                    _configPath = HostingEnvironment.MapPath(_CONFIGPATH);

                    //set the location to the xml file and open it for reading
                    using (FileStream fileStream = new FileStream(_CONFIGPATH, FileMode.Open, FileAccess.Read))
                    {
                        //read the xml file
                        using (StreamReader streamReader = new StreamReader(fileStream))
                        {
                            //load the xml stream into xmldoc
                            string xml = streamReader.ReadToEnd().Trim();

                            //did the configuration file change?
                            if (String.Compare(xml, _configCompare, StringComparison.InvariantCultureIgnoreCase) != 0)
                            {
                                //reload the configuration file
                                XmlDocument xdoc = new XmlDocument();
                                xdoc.LoadXml(xml);

                                _configCompare = xml;

                                _healthPlansInputFilePath = string.Format("{0}/{1}", _currentDirectory, xdoc.SelectSingleNode("/Config/HealthPlansInputFilePath").InnerXml.ToString());
                                _rateAreasInputFilePath = string.Format("{0}/{1}", _currentDirectory, xdoc.SelectSingleNode("/Config/HealthRatesInputFilePath").InnerXml.ToString());
                                _slcpOutputFilePath = string.Format("{0}/{1}", _currentDirectory, xdoc.SelectSingleNode("/Config/SLCPOutputFilePath").InnerXml.ToString());
                                _shutdown = bool.Parse(string.Format("{0}", xdoc.SelectSingleNode("/Config/Shutdown").InnerXml.ToString()));

                                xdoc = null;
                                xml = null;
                            }

                        }   //StreamReader

                    }   //FileStream

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    //release writer lock
                    if (_settingsLock.IsWriterLockHeld)
                    {
                        _settingsLock.ReleaseWriterLock();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //primary loop
        private static void MainWorkerLoop()
        {
            //check in
            _primaryThreadStarted.Set();

            //loop forever
            while (1 == 1)
            {
                try
                {
                    //acquire writer lock
                    _mainWorkerLock.AcquireWriterLock(1000);

                    try
                    {
                        GetApplicationSettings();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    finally
                    {
                        //release writer lock
                        if (_mainWorkerLock.IsWriterLockHeld)
                        {
                            _mainWorkerLock.ReleaseWriterLock();
                        }
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                //sleep for awhile
                Thread.Sleep(TimeSpan.FromSeconds(10));

            }   //while
        }

        //secondary loop
        private static void CheckPrimaryThreadAlive()
        {
            //loop forever
            while (1 == 1)
            {
                try
                {
                    //wait for primary thread to check in
                    if (_primaryThreadStarted.WaitOne(0, false))
                    {
                        //is primary thread still alive?
                        if (!_primaryThread.IsAlive)
                        {
                            //spawn new thread since primary is dead
                            ThreadStart start = new ThreadStart(MainWorkerLoop);
                            _primaryThread = new Thread(start);
                            _primaryThread.Start();
                        }
                    }

                    //sleep for a while
                    Thread.Sleep(TimeSpan.FromSeconds(60));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

    }
}

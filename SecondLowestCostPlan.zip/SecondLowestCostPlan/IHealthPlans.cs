﻿using System;
using System.Collections;

namespace SecondLowestCostPlan
{
    /**
     * Every Health Plan shall have a State and Rate Area
     * Every Health Plan shall read CSV files.
     */
    public interface IHealthPlans
    {
        string State { get; set; }

        int RateArea { get; set; }

        IList ProcessCSV(string path);
    }
}

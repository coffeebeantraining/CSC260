﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SecondLowestCostPlan
{
    public abstract class HealthPlans : IHealthPlans
    {

        private string _PlanID;
        private string _MetalLevel;
        private double _Rate;

        public string PlanID { get => _PlanID; set => _PlanID = value; }

        public string MetalLevel { get => _MetalLevel; set => _MetalLevel = value; }

        public double Rate { get => _Rate; set => _Rate = value; }

        public string State { get; set; }

        public int RateArea { get; set; }

        public virtual IList ProcessCSV(string path)
        {
            throw new NotImplementedException();
        }

        public virtual bool UpdateHealthPlans()
        {
            throw new NotImplementedException();
        }
    }
}

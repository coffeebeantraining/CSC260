﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLowestCostPlan
{
    class SLCPImpl : RateAreas
    {

        public override IList ProcessCSV(string path)
        {

            var csvToList = File.ReadAllLines(path)
                .Skip(1)
                .Where(columns => columns.Length > 0)
                .Where(columns => columns != string.Empty)
                .Select(columns => columns.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                .Select(columns => new SLCPImpl()
                {
                    ZipCode = columns[0]    //requirement - order fixed no sorting.
                }).Distinct()
                    .ToList();

            return csvToList;
        }

        public List<Data> CalculateSLCP(List<SLCPImpl> slcpList, List<HealthPlansImpl> plansList, List<RateAreasImpl> ratesList)
        {
            List<Data> dataList = new List<Data>();
            List<Data> outList = new List<Data>();
            HashSet<Data> unique = new HashSet<Data>();
            bool _firstPass = true;
            string _prevMetalLevel = null;

            foreach (var zip in slcpList)
            {
                foreach (var rate in ratesList)
                {
                    if (zip.ZipCode.Equals(rate.ZipCode))
                    {
                        foreach (var plan in plansList)
                        {
                            if (rate.State == plan.State && rate.RateArea == plan.RateArea)
                            {
                                if (_firstPass)
                                {
                                    _prevMetalLevel = plan.MetalLevel;
                                    _firstPass = false;
                                    Data d = new Data
                                    {
                                        PlanID = plan.PlanID,
                                        State = rate.State,
                                        ZipCode = rate.ZipCode,
                                        CountyCode = rate.CountyCode,
                                        Name = rate.Name,
                                        MetalLevel = plan.MetalLevel,
                                        Rate = plan.Rate,
                                        RateArea = plan.RateArea
                                    };
                                    dataList.Add(d);
                                }
                                else
                                {
                                    if (_prevMetalLevel != plan.MetalLevel)
                                    {
                                        Data copy = new Data
                                        {
                                            PlanID = plan.PlanID,
                                            State = rate.State,
                                            ZipCode = rate.ZipCode,
                                            CountyCode = rate.CountyCode,
                                            Name = rate.Name,
                                            MetalLevel = plan.MetalLevel,
                                            Rate = plan.Rate,
                                            RateArea = plan.RateArea
                                        };

                                        //select minimun rate
                                        var slcRate = dataList.Min(m => m.Rate);

                                        //select next higher rate
                                        var i = 0;
                                        for (i = 0; i < dataList.Count; ++i)
                                        {
                                            if (slcRate != dataList[i].Rate)
                                            {
                                                slcRate = dataList[i].Rate;
                                                break;
                                            }
                                        }

                                        //add to file output list
                                        if (dataList.Count == 1)
                                        {
                                            unique.Add(dataList[0]);
                                        }
                                        else
                                        {
                                            unique.Add(dataList[i]);
                                        }


                                        //add to new data output list to write to file.
                                        dataList = new List<Data>();
                                        dataList.Add(copy);
                                        _prevMetalLevel = plan.MetalLevel;

                                    }
                                    else
                                    {
                                        Data d = new Data
                                        {
                                            PlanID = plan.PlanID,
                                            State = rate.State,
                                            ZipCode = rate.ZipCode,
                                            CountyCode = rate.CountyCode,
                                            Name = rate.Name,
                                            MetalLevel = plan.MetalLevel,
                                            Rate = plan.Rate,
                                            RateArea = plan.RateArea
                                        };
                                        dataList.Add(d);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return unique.ToList();
        }

        public void WriteToFile(List<Data> sclpList)
        {
            using (FileStream fileStream = new FileStream(Config.SlcpOutputFilePath, FileMode.Open, FileAccess.Write))
            {
                using (StreamWriter streamWriter = new StreamWriter(fileStream))
                {
                    streamWriter.WriteLine("zipcode,rate,planid,state,countycode,name,metallevel,ratearea");
                    foreach (Data d in sclpList)
                    {
                        Console.WriteLine("{0} {1} {2} {3} {4} {5} {6} {7}", d.ZipCode, d.Rate.ToString("###.00"), d.PlanID, d.State, d.CountyCode, d.Name, d.MetalLevel, d.RateArea);
                        streamWriter.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7}", d.ZipCode, d.Rate.ToString("###.00"), d.PlanID, d.State, d.CountyCode, d.Name, d.MetalLevel, d.RateArea);
                    }
                }
            }
        }
    }
}

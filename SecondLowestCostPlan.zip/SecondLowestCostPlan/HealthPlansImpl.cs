﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;

namespace SecondLowestCostPlan
{
    public class HealthPlansImpl : HealthPlans
    {

        public HealthPlansImpl()
        {
        }

        public override IList ProcessCSV(string path)
        {
            var csvToList = File.ReadAllLines(path)
            .Skip(1)
            .Where(columns => columns.Length > 0)
            .Select(columns => columns.Split(','))
            .Select(columns => new HealthPlansImpl()
            {
                PlanID = columns[0],
                State = columns[1],
                MetalLevel = columns[2],
                Rate = double.Parse(columns[3]),
                RateArea = int.Parse(columns[4])
            }).Distinct()
                .OrderBy(ord => ord.State)
                .ThenBy(ord => ord.MetalLevel)
                .ThenBy(ord => ord.RateArea)
                .ThenBy(ord => ord.Rate)
                .ToList();

            return csvToList;
        }

        public override bool UpdateHealthPlans()
        {
            bool refresh = false;
            //set the location to the csv file and open it for reading
            using (FileStream fileStream = new FileStream(Config.HealthPlansInputFilePath, FileMode.Open, FileAccess.Read))
            {
                //read csv file
                using (StreamReader streamReader = new StreamReader(fileStream))
                {
                    //load the plans into memory
                    string _healthPlans = streamReader.ReadToEnd().Trim();

                    //did the configuration file change?
                    if (String.Compare(_healthPlans, Config.HealthPlansCompare, StringComparison.InvariantCultureIgnoreCase) != 0)
                    {
                        Config.HealthPlansCompare = _healthPlans;
                        refresh = true;
                    }

                }   //StreamReader

            }   //FileStream

            return refresh;
        }

    }
}

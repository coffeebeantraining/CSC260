﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLowestCostPlan
{

    class Data : IHealthPlans
    {
        private string _PlanID;
        private string _MetalLevel;
        private double _Rate;
        private string _ZipCode;
        private string _CountyCode;
        private string _Name;

        public string PlanID { get => _PlanID; set => _PlanID = value; }
        public string MetalLevel { get => _MetalLevel; set => _MetalLevel = value; }
        public double Rate { get => _Rate; set => _Rate = value; }
        public string ZipCode { get => _ZipCode; set => _ZipCode = value; }
        public string CountyCode { get => _CountyCode; set => _CountyCode = value; }
        public string Name { get => _Name; set => _Name = value; }

        public string State { get; set; }

        public int RateArea { get; set; }

        public IList ProcessCSV(string path)
        {
            throw new NotImplementedException();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace SecondLowestCostPlan
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            //Initialize the configuration
            Config.CheckInstance();

            //Create Health Plans Instance
            var HealthPlans = new HealthPlansImpl();
            List<HealthPlansImpl> plansList = null;

            //Create Rate Areas Instance
            var RateAreas = new RateAreasImpl();
            List<RateAreasImpl> ratesList = null;

            //Create Second Lowest Cost Plan Instance
            var Slcp = new SLCPImpl();
            List<SLCPImpl> slcpList = null;

            bool _calculateSLCP = false;

            while (!Config.Shutdown)
            {
                _calculateSLCP = false;

                //Check Health Plans Changed?
                if (HealthPlans.UpdateHealthPlans())
                {
                    Console.WriteLine("***Change Detected*** - Updating Health Plans.");
                    plansList = (List<HealthPlansImpl>)HealthPlans.ProcessCSV(Config.HealthPlansInputFilePath);
                    _calculateSLCP = true;
                }

                //Check Rate Areas changed?
                if (RateAreas.UpdateRateAreas())
                {
                    Console.WriteLine("***Change Detected*** - Updating Rate Areas.");
                    ratesList = (List<RateAreasImpl>)RateAreas.ProcessCSV(Config.HealthRatesInputFilePath);
                    _calculateSLCP = true;
                }

                //Calculate SLCP
                if (_calculateSLCP)
                {
                    //read the slcp.csv file
                    slcpList = (List<SLCPImpl>)Slcp.ProcessCSV(Config.SlcpOutputFilePath);

                    //calculate second lowest cost plans
                    List<Data> outList = Slcp.CalculateSLCP(slcpList, plansList, ratesList);

                    //Display Second Lowest Cost Plan for All Health Plans
                    Slcp.WriteToFile(outList);
                }

                Console.WriteLine("Monitoring Health Plans");

                //sleep for five seconds
                Thread.Sleep(TimeSpan.FromSeconds(5));
            }

        }




    }
}
